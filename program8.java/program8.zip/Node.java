public class Node {
        String data;
        Node left, right;

        public Node(String data) {
            this.data = data;
            left = right = null;
        }
    }
