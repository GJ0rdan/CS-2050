import java.io.*;
import java.util.ArrayList;
import java.util.Collections;

public class program6 {

    //Bubble sort and selection sort using integers
    public static void selectionSort(int[] array)
    {
        for (int i = 0; i < array.length -1; i++)
        {
            int minIndex = i;
            for (int j = i+1; j < array.length; j++)
                if (array[j] < array[minIndex])
                    minIndex = j;
            int temp = array[minIndex];
            array[minIndex] = array[i];
            array[i] = temp;
        }
    }

    public static void MyBubbleSort(int[] theArray) {
        int temp;

        for (int i = 0; i < theArray.length - 1; i++) {
            for (int j = i + 1; j < theArray.length; j++) {
                if (theArray[j] < theArray[i]) {
                    temp = theArray[i];
                    theArray[i] = theArray[j];
                    theArray[j] = temp;
                }
            }
        }
    }
    public static void selectionSortString(String[] array)
    {
        for (int i = 0; i < array.length -1; i++)
        {
            int minIndex = i;
            for (int j = i+1; j < array.length; j++)
                if (array[j].compareTo(array[minIndex]) < 0)
                    minIndex = j;
            String temp = array[minIndex];
            array[minIndex] = array[i];
            array[i] = temp;
        }
    }
    public static void MyBubbleSortString(String[] theArray) {
        String temp;
        for (int i = 0; i < theArray.length - 1; i++) {
            for (int j = i + 1; j < theArray.length; j++) {
                if (theArray[j].compareTo(theArray[i]) > 0) {
                    temp = theArray[i];
                    theArray[i] = theArray[j];
                    theArray[j] = temp;
                }
            }
        }
    }
    public static void main(String[] args) throws Exception {
        // two integer arrays for bubble and selection sort 1 array list for ints.
        int[] bubbleSortInt = new int[20000];
        int[] selectionSortInt = new int[20000];
        ArrayList<Integer> arrayListInt = new ArrayList<>();

        //two String arrays for bubble and selection sort
        String[] bubbleSortStr = new String[10000];
        String[] selectionSortStr = new String[10000];
        ArrayList<String> arrayListStr = new ArrayList<>();


        long billion = 1000000000;

        //Reading in Integers to the list
        try (BufferedReader input = new BufferedReader(new FileReader("NumbersInFile.txt"))) {
            String line;
            int index = 0;

            //reading in the integer text file and filling the arrays
            while ((line = input.readLine()) != null) {
                int number = Integer.parseInt(line);
                bubbleSortInt[index] = number;
                selectionSortInt[index] = number;
                arrayListInt.add(number);
                index++;
            }
            input.close();
        }catch(IOException e){
            e.printStackTrace();
        }
        //reading in Strings
        try (BufferedReader input = new BufferedReader(new FileReader("StringsInFIle"))) {
            String line;
            int index = 0;

            //reading in the String text file and filling the arrays
            while ((line = input.readLine()) != null) {
                bubbleSortStr[index] = line;
                selectionSortStr[index] = line;
                arrayListStr.add(line);
                index++;
            }
            input.close();
        }catch(IOException e){
            e.printStackTrace();
        }


        // timing the Integer arrays

        //selection sort Int time
        double SelectionSortStartTime = System.nanoTime();
        selectionSort(selectionSortInt);
        double SelectionSortEndTime = System.nanoTime();
        double selectionSortDifference = (SelectionSortEndTime - SelectionSortStartTime)/ billion;

        //bubble sort Int time
        double bubbleSortStartTime = System.nanoTime();
        MyBubbleSort(bubbleSortInt);
        double bubbleSortEndTime = System.nanoTime();
        double bubbleSortDifference = (bubbleSortEndTime - bubbleSortStartTime)/ billion;

        //timing the String arrays

        //selection sort String time
        double SelectionSortStartTimeStr = System.nanoTime();
        selectionSortString(selectionSortStr);
        double SelectionSortEndTimeStr = System.nanoTime();
        double selectionSortDifferenceStr = (SelectionSortEndTimeStr - SelectionSortStartTimeStr)/ billion;


        //bubble sort String time
        double bubbleSortStartTimeStr = System.nanoTime();
        MyBubbleSortString(bubbleSortStr);
        double bubbleSortEndTimeStr = System.nanoTime();
        double bubbleSortDifferenceStr = (bubbleSortEndTimeStr - bubbleSortStartTimeStr)/billion;

        //Array list sorting
        double arrayListStartTime = System.nanoTime();
        Collections.sort(arrayListStr);
        double arrayListEndTime = System.nanoTime();
        double arrayListDifference = (arrayListEndTime - arrayListStartTime)/billion;


        try (BufferedWriter output = new BufferedWriter(new FileWriter("results.txt"))) {
            //print array for verification of sorting

            output.write(("Selection Sort Time for String: " + selectionSortDifferenceStr));
            output.newLine();
            output.write(("Bubble sort time for string: " + bubbleSortDifferenceStr));
            output.newLine();
            output.write(("Selection Sort Time for Integer: " + selectionSortDifference));
            output.newLine();
            output.write(("Bubble sort time for Integer: " + bubbleSortDifference));
            output.newLine();
            output.write(("Array List Time: " + arrayListDifference));

            /*
            //print array for verification of sorting
            for (int i = 0; i < bubbleSortStr.length; i++) {
                output.write((selectionSortStr[i]));
                output.newLine();
            }
            */

            output.close();
        }catch (IOException e){
            e.printStackTrace();
        }

    }

}

