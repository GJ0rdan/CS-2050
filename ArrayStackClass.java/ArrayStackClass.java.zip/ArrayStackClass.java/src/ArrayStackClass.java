//Garret Jordan

public class ArrayStackClass {


    char nums;

    char top = 0;

    public void push(sc) {
        stack[top] = nums;
        top++;
    }

    public char pop() {
        top--;
        char nums = stack[top];
        stack[top] = 0;
        return nums;
    }

    public int peek() {
        char nums = stack[top - 1];
        return nums;
    }
    public char size(){
        return top;
    }
    public boolean empty() {
        stack[top]
        top--;
    }
    public N(int N){
        this.N = N;
    }

    public string testValidity(){
        if (this.sc.nextLine() == "+" || "-"){
            return true;
        }
        elseif (sc.nextLine() == "*" || "%"){
            return true;
        }
        elseif(sc.nextLine() == 0,1,2,3,4,5,6,7,8,9){
            return true;
        }
        elseif(sc.nextLine())
    }
}
