
// Garret Jordan

import java.util.*;
import java.io.File;
public class Main {
    public static void main(String[] args) throws Exception
        {
            string stack[] = new string[];
            string s;

            File file = new File("C:\\Users\\garre\\Downloads\\Program3.txt");
            Scanner program3 = new Scanner(file);

            while(sc.hasNextLine())
            {
                System.out.println(program3.nextLine());
            }

            N numN = new N();

            private static boolean Operator(char op)
            {
                return op == '+' || op == '-' || op == '*' || op == '/' || op == '(' || op == ')';
            }
            public static String InfixToPostfix (String s){
                string s;
                if (sc.nextLine() == *)

        }








        }
    }
}
